/***********************************************************
Title: Mod02-Lab02
Dev: RRoot
ChangeLog(When,Who,What)
1/1/30,RRoot,Created Script
*************************************************************/
Use Master;
go
If Exists (Select Name From SysDatabases Where Name = 'Mod2_Lab2_RRoot')
  Drop Database Mod2_Lab2_RRoot;
go

Create Database Mod2_Lab2_RRoot;
go

Use Mod2_Lab2_RRoot;
go

Create table Products
(ProductID int Constraint pkProducts Primary Key
,ProductName nvarchar(100) Constraint uqProductName Unique
,ProductListPrice nvarchar(1000) Constraint ckProductListPriceGTOrEqZero Check (ProductListPrice >= 0)
);
go

Create table Categories
(CategoryID int Constraint pkCategories Primary Key
,CategoryName nvarchar(100) Constraint uqCategoryNameName Unique
);
go
